from django.shortcuts import render
from .models import DBOperations

def index(request):
    return render(request, "index.html")

def login(request):
    return render(request, "Login.html")

# Usernames: 1. Admin1     | 2. Admin2     | 3. Admin3     | 4. Admin4
# Passwords: 1. Admin1@123 | 2. Admin2@123 | 3. Admin3@123 | 4. Admin4@123
def adminpage(request):
    if request.method=="POST":
        userid = request.POST.get("username")
        password = request.POST.get("password")
        obj = DBOperations()
        stat = obj.loginuser(userid, password)
        if stat == 'success':
            return render(request, "AdminPage.html")
        else:
            return render(request, "Login.html")

def carregistration(request):
    return render(request, "CarRegistration.html")

def caradded(request):
    if request.method == "POST":
        id = request.POST.get("carid")
        name = request.POST.get("carname")
        company = request.POST.get("carcompany")
        ctype = request.POST.get("cartype")
        wheels = request.POST.get("wheels")
        engcap = request.POST.get("engcap")
        ftype = request.POST.get("fueltype")
        price = request.POST.get("price")
        img = request.POST.get("image")
        obj = DBOperations()
        stat = obj.addcar(id,name,company,ctype,wheels,engcap,ftype,price,img)
        dic = {}
        dic['id'] = id
        dic['name'] = name
        dic['company'] = company
        dic['cartype'] = ctype
        dic['wheels'] = wheels
        dic['enginecapacity'] = engcap
        dic['fueltype'] = ftype
        dic['price'] = price
        dic['image'] = img
        dic['status'] = stat
        return render(request, "CarAdded.html", dic)

def customerregistration(request):
    return render(request, "CustomerRegistration.html")

def custadded(request):
    if request.method == "POST":
        id = request.POST.get("custid")
        name = request.POST.get("custname")
        mob = request.POST.get("mobileno")
        email = request.POST.get("emailid")
        add = request.POST.get("address")
        carid = request.POST.get("carid")
        obj = DBOperations()
        stat = obj.addcust(id,name,mob,email,add,carid)
        dic = {}
        dic['id'] = id
        dic['name'] = name
        dic['mobileno'] = mob
        dic['emailid'] = email
        dic['address'] = add
        dic['carid'] = carid
        dic['status'] = stat
        return render(request, "CustAdded.html",dic)

def allcars(request):
    obj = DBOperations()
    data = obj.getcars()
    imglist = []
    for rec in data:
        imglist.append(rec[8])
    imgtup = tuple(imglist)
    infolist = []
    for rec in data:
        lst = list(rec)
        del lst[8]
        infolist.append(tuple(lst))
    infotup = tuple(infolist)
    return render(request, "AllCars.html", {"images":imgtup, "info":infotup})

def allcustomers(request):
    obj = DBOperations()
    data = obj.getcustomers()
    return render(request, "AllCustomers.html", {"list":data})

def modifycarprice(request):
    return render(request, "ModifyCarPrice.html")

def pricemod(request):
    if request.method == "POST":
        cid = request.POST.get("carid")
        newprc = request.POST.get("newprice")
        obj = DBOperations()
        stat = obj.modifyprice(cid, newprc)
        dic = {}
        dic['carid'] = cid
        dic['newprc'] = newprc
        dic['status'] = stat
        return render(request, "PriceModified.html", dic)

def modifycustomers(request):
    return render(request, "ModifyCustMob.html")

def custmobnomod(request):
    if request.method == "POST":
        custid = request.POST.get("custid")
        mobno = request.POST.get("mobno")
        obj = DBOperations()
        stat = obj.modifymobno(custid, mobno)
        dic = {}
        dic['custid'] = custid
        dic['mobno'] = mobno
        dic['status'] = stat
        return render(request, "MobNoModified.html", dic)

def searchbycustid(request):
    return render(request, "SearchCustByID.html")

def searchbyid(request):
    if request.method == "POST":
        id = int(request.POST.get("custid"))
        obj = DBOperations()
        data = obj.searchcustbyid(id)
        return render(request, "CustomerSearched.html", {"rec":data})

def searchbycustnm(request):
    return render(request, "SearchCustByName.html")

def searchbynm(request):
    if request.method == "POST":
        nm = request.POST.get("custnm")
        obj = DBOperations()
        data = obj.searchcustbynm(nm)
        return render(request, "CustomerSearched.html", {"rec":data})

def searchcar(request):
    return render(request, "SearchCar.html")

def carsearched(request):
    if request.method == "POST":
        id = int(request.POST.get("carid"))
        obj = DBOperations()
        data = obj.searchcar(id)
        imglist = []
        imglist.append(data[8])
        imgtup = tuple(imglist)
        infolist = []
        lst = list(data)
        del lst[8]
        infolist.append(tuple(lst))
        infotup = tuple(infolist)
        return render(request, "SearchedCar.html", {"image":imgtup, "info":infotup})

def compwisesearched(request):
    if request.method == "POST":
        company = request.POST.get("company")
        obj = DBOperations()
        data = obj.searchcarcompwise(company)
        imglist = []
        for rec in data:
            imglist.append(rec[8])
        imgtup = tuple(imglist)
        infolist = []
        for rec in data:
            lst = list(rec)
            del lst[8]
            infolist.append(tuple(lst))
        infotup = tuple(infolist)
        return render(request, "AllCars.html", {"images":imgtup, "info":infotup})

def typewisesearched(request):
    if request.method == "POST":
        type = request.POST.get("type")
        obj = DBOperations()
        data = obj.searchcartypewise(type)
        imglist = []
        for rec in data:
            imglist.append(rec[8])
        imgtup = tuple(imglist)
        infolist = []
        for rec in data:
            lst = list(rec)
            del lst[8]
            infolist.append(tuple(lst))
        infotup = tuple(infolist)
    return render(request, "AllCars.html", {"images":imgtup, "info":infotup})